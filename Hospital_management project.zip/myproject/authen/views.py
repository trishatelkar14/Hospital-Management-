from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login,logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.models import User
from .forms import RegisterForm, LoginForm,UpdateProfileForm, UpdatePasswordForm
# SIGNUP VIEW
def signup(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            # Hash the password properly
            user.set_password(form.cleaned_data['password'])
            user.save()
            messages.success(request, "Registration successful! You can now log in.")
            return redirect('signin')
        else:
            messages.error(request, "Please fix the errors below.")
    else:
        form = RegisterForm()
    return render(request, 'signup.html', {'form': form})

# SIGNIN VIEW
def signin(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f"Welcome, {user.username}!")
                return redirect('profile')
            else:
                messages.error(request, "Invalid username or password.")
    else:
        form = LoginForm()
    return render(request, 'signin.html', {'form': form})

# PROFILE VIEW
@login_required
def profile(request):
    return render(request, 'profile.html', {'user': request.user})
# UPDATE PROFILE VIEW
@login_required
def update_profile(request):
    if request.method == 'POST':
        form = UpdateProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile updated successfully!")
            return redirect('profile')
        else:
            messages.error(request, "Please fix the errors below.")
    else:
        form = UpdateProfileForm(instance=request.user)
    return render(request, 'update_profile.html', {'form': form})
# UPDATE PASSWORD VIEW
@login_required
def update_password(request):
    if request.method == 'POST':
        form = UpdatePasswordForm(user=request.user,data=request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request,user)
            messages.success(request,'Password Updated Successfully!...')
            return redirect('profile')
        else:
            messages.error(request,'Please fix the error below')
    
    else:
        form = UpdatePasswordForm(user=request.user)
    return render(request,'update_password.html',{'form':form}) 
# LOGOUT VIEW
@login_required
def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect('signin')

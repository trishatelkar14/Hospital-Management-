from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from .models import Doctor, Patient, MedicalReport, Appointment
from .forms import DoctorForm, PatientForm, MedicalReportForm, AppointmentForm
from django.contrib import messages
from django.db.models import Q


# ---------------- Doctor Views ----------------
def doctor_list(request):
    search = request.GET.get("q", "")
    if search:
        doctors = Doctor.objects.filter(
            Q(name__icontains=search) |
            Q(specialization__icontains=search) |
            Q(contact__icontains=search),
            is_deleted=False    # only active doctors
        )
    else:
        doctors = Doctor.objects.filter(is_deleted=False)
    return render(request, "doctor_list.html", {
        "doctors": doctors,
        "search": search
    })

def doctor_create(request):
    if request.method == "POST":
        form = DoctorForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Doctor added successfully.")
            return redirect("doctor_list")
    else:
        form = DoctorForm()
    return render(request, "doctor_form.html", {"form": form})

def doctor_update(request, pk):
    doctor = get_object_or_404(Doctor, id=pk)
    if request.method == "POST":
        form = DoctorForm(request.POST, request.FILES, instance=doctor)
        if form.is_valid():
            form.save()
            messages.success(request, "Doctor details updated successfully.")
            return redirect("doctor_list")
    else:
        form = DoctorForm(instance=doctor)
    return render(request, "doctor_form.html", {"form": form})

def doctor_delete(request, pk):
    doctor = get_object_or_404(Doctor, id=pk)
    if request.method == "POST":
        doctor.is_deleted = True
        doctor.deleted_at = timezone.now()
        doctor.save()
        messages.warning(request, "Doctor moved to trash.")
        return redirect("doctor_list")
    return render(request, "doctor_confirm_delete.html", {"doctor": doctor})

def doctor_history(request):
    doctors = Doctor.objects.filter(is_deleted=True)
    return render(request, "doctor_history.html", {"doctors": doctors})

def doctor_restore(request, pk):
    doctor = get_object_or_404(Doctor, id=pk, is_deleted=True)
    if request.method == "POST":
        doctor.is_deleted = False
        doctor.deleted_at = None
        doctor.save()
        messages.success(request, "Doctor restored successfully.")
        return redirect("doctor_history")
    return render(request, "doctor_restore.html", {"doctor": doctor})

def doctor_delete_permanent(request, pk):
    doctor = get_object_or_404(Doctor, id=pk, is_deleted=True)
    doctor.delete()
    messages.error(request, "Doctor deleted permanently.")
    return redirect("doctor_history")


# ---------------- Patient Views ----------------
def patient_list(request):
    search = request.GET.get("q","")
    if search:
        patients = Patient.objects.filter(
            Q(name__icontains=search) |
            Q(contact__icontains=search) |
            Q(address__icontains=search) |
            Q(disease__icontains=search) |
            Q(consulting__name__icontains=search) |          # doctor name
            Q(consulting__specialization__icontains=search)  # doctor specialization
        ).filter(is_deleted=False)
    else:
        patients = Patient.objects.filter(is_deleted=False)
    return render(request, "patient_list.html", {"patients": patients,'search':search})

def patient_create(request):
    if request.method == "POST":
        form = PatientForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Patient added successfully.")
            return redirect("patient_list")
    else:
        form = PatientForm()
    return render(request, "patient_form.html", {"form": form})

def patient_update(request, pk):
    patient = get_object_or_404(Patient, id=pk)
    if request.method == "POST":
        form = PatientForm(request.POST, request.FILES, instance=patient)
        if form.is_valid():
            form.save()
            messages.success(request, "Patient details updated successfully.")
            return redirect("patient_list")
    else:
        form = PatientForm(instance=patient)
    return render(request, "patient_form.html", {"form": form})

def patient_delete(request, pk):
    patient = get_object_or_404(Patient, id=pk)
    if request.method == "POST":
        patient.is_deleted = True
        patient.deleted_at = timezone.now()
        patient.save()
        messages.warning(request, "Patient moved to trash.")
        return redirect("patient_list")
    return render(request, "patient_confirm_delete.html", {"patient": patient})

def patient_history(request):
    patients = Patient.objects.filter(is_deleted=True)
    return render(request, "patient_history.html", {"patients": patients})

def patient_restore(request, pk):
    patient = get_object_or_404(Patient, id=pk, is_deleted=True)
    if request.method == "POST":
        patient.is_deleted = False
        patient.deleted_at = None
        patient.save()
        messages.success(request, "Patient restored successfully.")
        return redirect("patient_history")
    return render(request, "patient_restore.html", {"patient": patient})

def patient_delete_permanent(request, pk):
    patient = get_object_or_404(Patient, id=pk, is_deleted=True)
    patient.delete()
    messages.error(request, "Patient deleted permanently.")
    return redirect("patient_history")

from django.utils import timezone

# ---------------- Medical Report Views ----------------
def report_list(request):
    # Only show active reports
    reports = MedicalReport.objects.filter(is_deleted=False)
    return render(request, "report_list.html", {"reports": reports})

def report_create(request):
    if request.method == "POST":
        form = MedicalReportForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Report added successfully.")
            return redirect("report_list")
    else:
        form = MedicalReportForm()
    return render(request, "report_form.html", {"form": form})

def report_update(request, pk):
    report = get_object_or_404(MedicalReport, id=pk)
    if request.method == "POST":
        form = MedicalReportForm(request.POST, request.FILES, instance=report)
        if form.is_valid():
            form.save()
            messages.success(request, "Report updated successfully.")
            return redirect("report_list")
    else:
        form = MedicalReportForm(instance=report)
    return render(request, "report_form.html", {"form": form})

def report_delete(request, pk):
    report = get_object_or_404(MedicalReport, id=pk)
    if request.method == "POST":
        # Soft delete
        report.is_deleted = True
        report.deleted_at = timezone.now()
        report.save()
        messages.warning(request, "Report moved to trash.")
        return redirect("report_list")
    return render(request, "report_confirm_delete.html", {"report": report})

def report_history(request):
    reports = MedicalReport.objects.filter(is_deleted=True)
    return render(request, "report_history.html", {"reports": reports})

def report_restore(request, pk):
    report = get_object_or_404(MedicalReport, id=pk, is_deleted=True)
    if request.method == "POST":
        report.is_deleted = False
        report.deleted_at = None
        report.save()
        messages.success(request, "Report restored successfully.")
        return redirect("report_history")
    return render(request, "report_restore.html", {"report": report})

def report_delete_permanent(request, pk):
    report = get_object_or_404(MedicalReport, id=pk, is_deleted=True)
    report.delete()
    messages.error(request, "Report deleted permanently.")
    return redirect("report_history")



# ---------------- Appointment Views ----------------
def appointment_list(request):
    appointments = Appointment.objects.filter(is_deleted=False)
    return render(request, "appointment_list.html", {"appointments": appointments})

def appointment_create(request):
    if request.method == "POST":
        form = AppointmentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Appointment created successfully.")
            return redirect("appointment_list")
    else:
        form = AppointmentForm()
    return render(request, "appointment_form.html", {"form": form})

def appointment_update(request, pk):
    appointment = get_object_or_404(Appointment, id=pk)
    if request.method == "POST":
        form = AppointmentForm(request.POST, instance=appointment)
        if form.is_valid():
            form.save()
            messages.success(request, "Appointment updated successfully.")
            return redirect("appointment_list")
    else:
        form = AppointmentForm(instance=appointment)
    return render(request, "appointment_form.html", {"form": form})

def appointment_delete(request, pk):
    appointment = get_object_or_404(Appointment, id=pk)
    if request.method == "POST":
        appointment.is_deleted = True
        appointment.deleted_at = timezone.now()
        appointment.save()
        messages.warning(request, "Appointment moved to trash.")
        return redirect("appointment_list")
    return render(request, "appointment_confirm_delete.html", {"appointment": appointment})

def appointment_history(request):
    appointments = Appointment.objects.filter(is_deleted=True)
    return render(request, "appointment_history.html", {"appointments": appointments})

def appointment_restore(request, pk):
    appointment = Appointment.objects.filter(id=pk, is_deleted=True).first()
    if not appointment:
        messages.error(request, "Appointment not found or not deleted.")
        return redirect("appointment_history")

    appointment.is_deleted = False
    appointment.deleted_at = None
    appointment.save()
    messages.success(request, "Appointment restored successfully!")
    return redirect("appointment_list")

def appointment_delete_permanent(request, pk):
    appointment = get_object_or_404(Appointment, id=pk, is_deleted=True)
    appointment.delete()
    messages.error(request, "Appointment deleted permanently.")
    return redirect("appointment_history")
    
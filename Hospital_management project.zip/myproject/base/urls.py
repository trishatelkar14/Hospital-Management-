from django.urls import path
from base import views

urlpatterns = [

    # ---------------- Patient URLs ----------------
    path("", views.patient_list, name="patient_list"),  # default page
    path("patient/add/", views.patient_create, name="patient_create"),
    path("patient/update/<int:pk>/", views.patient_update, name="patient_update"),
    path("patient/delete/<int:pk>/", views.patient_delete, name="patient_delete"),
    path("patient/history/", views.patient_history, name="patient_history"),
    path("patient/restore/<int:pk>/", views.patient_restore, name="patient_restore"),
    path("patient/delete_permanent/<int:pk>/", views.patient_delete_permanent, name="patient_delete_permanent"),

    # ---------------- Doctor URLs ----------------
    path("doctors/", views.doctor_list, name="doctor_list"),
    path("doctor/add/", views.doctor_create, name="doctor_create"),
    path("doctor/update/<int:pk>/", views.doctor_update, name="doctor_update"),
    path("doctor/delete/<int:pk>/", views.doctor_delete, name="doctor_delete"),
    path("doctor/history/", views.doctor_history, name="doctor_history"),
    path("doctor/restore/<int:pk>/", views.doctor_restore, name="doctor_restore"),
    path("doctor/delete_permanent/<int:pk>/", views.doctor_delete_permanent, name="doctor_delete_permanent"),

    # ---------------- Medical Report URLs ----------------
    path("reports/", views.report_list, name="report_list"),
    path("report/add/", views.report_create, name="report_create"),
    path("report/update/<int:pk>/", views.report_update, name="report_update"),
    path("report/delete/<int:pk>/", views.report_delete, name="report_delete"),
    path("report/history/", views.report_history, name="report_history"),
    path("report/restore/<int:pk>/", views.report_restore, name="report_restore"),
    path("report/delete-permanent/<int:pk>/", views.report_delete_permanent, name="report_delete_permanent"),

    # ---------------- Appointment URLs ----------------
    path("appointments/", views.appointment_list, name="appointment_list"),
    path("appointment/add/", views.appointment_create, name="appointment_create"),
    path("appointment/update/<int:pk>/", views.appointment_update, name="appointment_update"),
    path("appointment/delete/<int:pk>/", views.appointment_delete, name="appointment_delete"),
    path("appointment/history/", views.appointment_history, name="appointment_history"),
    path("appointment/restore/<int:pk>/", views.appointment_restore, name="appointment_restore"),
    path("appointment/delete-permanent/<int:pk>/", views.appointment_delete_permanent, name="appointment_delete_permanent"),
]

from django.db import models

# Doctor Model
class Doctor(models.Model):
    name = models.CharField(max_length=50)
    specialization = models.CharField(max_length=100)
    contact = models.CharField(max_length=15)
    profile_pic = models.ImageField(upload_to="doctors/", blank=True, null=True)  # media file
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)

    def __str__(self):
        return f"Dr. {self.name} - {self.specialization}"


# Patient Model
class Patient(models.Model):
    name = models.CharField(max_length=30)
    age = models.IntegerField()
    gender = models.CharField(max_length=10, choices=[("Male","Male"),("Female","Female"),("Other","Other")])
    address = models.CharField(max_length=100)
    contact = models.CharField(max_length=15)
    disease = models.CharField(max_length=100)
    admission_date = models.DateField(null=True, blank=True)
    discharge_date = models.DateField(null=True, blank=True)
    photo = models.ImageField(upload_to="patients/", blank=True, null=True)  # media file
    
    consulting = models.ForeignKey(Doctor, on_delete=models.SET_NULL, null=True, blank=True, related_name="patients")
    
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(auto_now_add=True, blank=True, null=True)

    def __str__(self):
        return self.name


# Medical Report Model 
class MedicalReport(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name="reports")
    title = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    report_file = models.FileField(upload_to="reports/")  # can upload PDF/Word/Image
    uploaded_at = models.DateTimeField(auto_now_add=True)
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.title} - {self.patient.name}"


# Appointment Model
class Appointment(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name="appointments")
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE, related_name="appointments")
    appointment_date = models.DateTimeField()
    reason = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
     # 🔽 Add these two fields
    is_deleted = models.BooleanField(default=False)
    deleted_at = models.DateTimeField(null=True, blank=True)
    def __str__(self):
        return f"Appointment: {self.patient.name} with Dr. {self.doctor.name} on {self.appointment_date.strftime('%Y-%m-%d %H:%M')}"
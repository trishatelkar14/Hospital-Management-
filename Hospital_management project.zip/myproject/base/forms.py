from django import forms
from .models import Doctor, Patient, MedicalReport, Appointment

# ---------------- Doctor Form ----------------
class DoctorForm(forms.ModelForm):
    class Meta:
        model = Doctor
        fields = ["name", "specialization", "contact", "profile_pic"]


# ---------------- Patient Form ----------------
class PatientForm(forms.ModelForm):
    class Meta:
        model = Patient
        fields = [
            "name",
            "age",
            "gender",
            "address",
            "contact",
            "disease",
            "admission_date",
            "discharge_date",
            "photo",
            "consulting",
        ]


# ---------------- Medical Report Form ----------------
class MedicalReportForm(forms.ModelForm):
    class Meta:
        model = MedicalReport
        fields = ["patient", "title", "description", "report_file"]


# ---------------- Appointment Form ----------------
class AppointmentForm(forms.ModelForm):
    class Meta:
        model = Appointment
        fields = ["patient", "doctor", "appointment_date", "reason"]
        widgets = {
            "appointment_date": forms.DateTimeInput(attrs={"type": "datetime-local"})
        }
